# This code is applying a ARIMA model to the linear part of the data
# and then applying ANN modelling on the residuals obtained from the ARIMA forecasting.
library(forecast)
library(tseries)
#library(hydroGOF)
library(neuralnet)
setwd("/home/priyanka/Desktop/mysafestpath/temporal_analysis")
par(mfrow=c(1,1))
crime_records=read.csv("/home/priyanka/Desktop/mysafestpath/spatio_analysis/crimerecords.csv",header=T,sep="\t")
for(j in 1:163)
{
  num=1
  #print(num)
  tmp=toString(j)
  filename=paste(tmp,".csv",sep="")
  sunspotcomp=read.csv(filename,header=T,sep ="\t")
  #print(sunspotcomp)
  #print(filename)
  #Training data first 250 data points
  sunspot_train=sunspotcomp[c(1:75),2,drop=F]
  #Validation set 63 data points for validation
  sunspot_valid=sunspotcomp[c(76:95),2,drop=F]
  st=sunspot_train
  sv=sunspot_valid
  #print(st)
  # number of differening required to make series stationary
  #diff=nsdiffs(st)
  #print(diff)
  #plot ACF of trainng data
  st=as.ts(st)
  #print(st)
  sv=as.ts(sv)
  #plot.ts(st,col="Red",ylab="Number of FIRs",xlab="1-Jan-14 to 6-Apr-14",main="Frequency of FIR Records (Time Period: 1 day)")
  a=acf(diff(st,9),plot=F)
  #plot(a,main="Autocorrelation function of Differenced FIR Records training data",col="Slateblue",ci.col="Red")
  b=pacf(diff(st,9),plot=F)
  #plot(b,main=" Partial Autocorrelation function of Differenced FIR REcords training data",col="Slateblue",ci.col="Red")
  par(mfrow=c(1,1))
  # Based on autocorrelation and pacf plot, a model of arima(2,0,0)(1,1,0)9 is tested
  s201=arima(st,order=c(4,0,0),seasonal=c(1,1,0))
  #par(mfrow=c(2,1))
  
  #plot.ts(residuals(s201),main="Residuals-ARIMA(2,0,1)-Training Data",ylab="Residuals",col="Blue")
  #abline(h=mean(residuals(s201)))
  #acf(residuals(s201),na.action=na.remove,main="ACF-Residuals-ARIMA(2,0,1)-Training Data",col="Slateblue",ci.col="Red")
  #s900
  #auto.arima(st,max.p=10,max.order=14) #Gives arima(2,0,1) diff.forval=as.numeric(forvalue[4])
  forvalue=forecast(s201,h=1)
  forval=as.numeric(forvalue[4])
  for(i in 1:20){
    stt=c(st,sv[1:i])
    newfit=arima(stt,order=c(2,0,0),seasonal=c(1,1,0))
    a=forecast(newfit,h=1)
    forval=c(forval,as.numeric(a[4]))
  }
  #print(forval)
  forval=as.ts(forval)
  #ts.plot(forval,sv,xlab="day",ylab="FIR Records",lty=c(1:2),col=c("Red","Blue"),main="Forecast of FIR REcords by ARIMA(2,0,1)")
  #legend('top','groups',c("Forecast","Actual"), lty = c(1,2),col=c('Red','Blue'),ncol=2,bty ="n")
  for_residual=forval-sv
  fr=for_residual
  residuals=residuals(s201)
  r=residuals
  #ANN part 
  train_input=cbind(r[1:73],r[2:74])
  train_output=r[3:75]
  train_data=cbind(train_input,train_output)
  colnames(train_data)=c('I1','I2','OUT')
  ann=neuralnet(OUT~I1+I2,train_data,hidden=1,threshold=20,lifesign.step=5000)
  #plot(ann,main="Diagram of ANN(4,1,1) model for residuals-FIR Records Data")
  val=ann$net.result
  val=as.numeric(unlist(val))
  valts=as.ts(val)
  stts=as.ts(r[3:75])
  testdata=cbind(fr[1:18],fr[2:19])
  testdata=as.data.frame(testdata)
  ann.results=compute(ann,testdata)
  result=as.numeric(unlist(ann.results$net.result))
  result=as.ts(result)
  #print(result)
  expval=as.ts(fr[3:20])
  #ts.plot(result,expval,xlab="year",ylab="FIR Records",lty=c(1:2),col=c("Red","Blue"))
  finalpredict=result+as.ts(forval[3:20])
  sv_data=as.ts(sv[3:20])
  if(j==163)
  {
  ts.plot(sv_data, finalpredict,col=c("red","blue"),lty=c(1:2),main="Forecast-ANN(2)+ARIMA(2,0,1)-FIR Records")
  legend('top','groups',c("Actual","Forecast"), lty = c(1,2),col=c('Red','blue'),ncol=2,bty ="n")
  }
  #Compute MSE and MAD for ARIMA, ANN and Hybrid Model
  final_result=finalpredict[16]+crime_records[j,4]  
  #print(finalpredict[16])
  if(j==1)
  {
    data=final_result
  #  print(data)
  }
  else
    data=rbind(data,final_result)
  #print (j)
  #print(data)
}
#}
#data=as.data.frame(result)

data=cbind(crime_records[1:163,c(1)],as.integer(data),crime_records[1:163,c(5:6)])

#print(data[,c(2:4)])
#data_final=data[,c(1:4)]
#print(data_final)
write.csv(data[,c(1:4)], file = "Data.csv",row.names=FALSE)
#dat=read.csv("Data.csv",header=T)
#print(dat)

