#!/bin/sh

for (( i=2; i <= 163; i++ ))
do
 cp 1.ods $i.ods
done
