import Tkinter as tk
import ttk
import safest_path
#import mapPath
#import openImage
import webbrowser
import time
from PIL import ImageDraw
import webbrowser
from PIL import Image
from PIL import ImageFont
from PIL import ImageTk
import tkMessageBox
import tkFont
import os

import csv
with open('../temporal_analysis/Data.csv', 'Ur') as f:
    data = list(rec
                for rec in csv.reader(f, delimiter=','))

from collections import defaultdict
choices = defaultdict(list)
count = 0
for i in data[1:]:
    temp = [str(count)]
    count+=1
    temp.append(i[1])
    temp.append(i[2])
    temp.append(i[3])
    choices[i[0].lower()]=temp
'''
choices = {
    'najafgarh': 0,
    'chhawala': 1,
    'mundka': 2,
    'kanjawla': 3,
    'south campus': 4,
    'dwarka': 5,
    'bawana': 6,
    'mianwali':7,
}
'''


def calculate(*args):
    try:
        '''
        fd = open("path.txt",'w')
        fd.write("")
        fd.close()
        fp = open("map.jpg", "rb")
        im = Image.open(fp) # open from file object
        '''
        safest_path.findPath(int(choices[source.get().lower()][0]),int(choices[dest.get().lower()][0]))
        meters.set(safest_path.findPath(int(choices[source.get().lower()][0]),int(choices[dest.get().lower()][0])))
        #execfile('mapPath.py')
        #mapPath.drawPath()
        #mapPath.fp.close()
        #del im
        os.system("python mapPath.py")
    except:
        meters.set("Please enter a valid location")
    return

    
    
root = tk.Tk()
root.title("Safest Path Finder")
RWidth = root.winfo_screenwidth()
RHeight = root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (RWidth/2, RHeight))
#root.geometry("683x768")

background_image=ImageTk.PhotoImage(file="MAP_FINAL.jpg")
background_label = ttk.Label(root, image=background_image)
background_label.place(x=0, y=0, relwidth=1, relheight=1)


mainframe = tk.Frame(root, background = "#F0EEE8")
mainframe.grid(column=0, row=0)
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)

feet = tk.StringVar()
meters = tk.StringVar()

source = tk.StringVar()
dest = tk.StringVar()


source_entry = ttk.Entry(mainframe, width=40, textvariable=source)
source_entry.grid(column=2, row=0)
dest_entry = ttk.Entry(mainframe, width=40, textvariable=dest)
dest_entry.grid(column=2, row=1)



#configure(background='black')
#ttk.Label(mainframe, textvariable=meters).configure(background='blue')
#ttk.Label(mainframe, text="Source").configure(background='blue')
#ttk.Label(mainframe, text="Destination").configure(background='blue')

labelPath = ttk.Label(mainframe, textvariable=meters, background="#F0EEE8").grid(column=2, row=4)
ttk.Button(mainframe, text="Find Path", command=calculate).grid(column=2, row=2)

labelSource = ttk.Label(mainframe, text="Source", background="#F0EEE8").grid(column=1, row=0)
labelDest = ttk.Label(mainframe, text="Destination", background="#F0EEE8").grid(column=1, row=1)
#ttk.Label(mainframe, text="is equivalent to").grid(column=1, row=2, sticky=E)
#ttk.Label(mainframe, text="meters").grid(column=3, row=2, sticky=W)

for child in mainframe.winfo_children(): child.grid_configure(padx=5, pady=5)

source_entry.focus()
root.bind('<Return>', calculate)

root.mainloop()
