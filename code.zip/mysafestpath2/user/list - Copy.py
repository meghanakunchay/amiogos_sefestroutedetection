from Tkinter import *
import ttk
import safest_path
import mapPath
#import openImage
import webbrowser
import time

def calculate(*args):
    try:
        safest_path.findPath(source.get(),dest.get())
        
        #value = float(source.get())
        meters.set(safest_path.findPath(source.get(),dest.get()))
        mapPath.drawPath()
        #webbrowser.open("result.jpg")
        #openImage.openThisImage()
    except ValueError:
        pass
    
root = Tk()
root.title("Safest Path Finder")

mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)

feet = StringVar()
meters = StringVar()

source = StringVar()
dest = StringVar()


source_entry = ttk.Entry(mainframe, width=7, textvariable=source)
source_entry.grid(column=2, row=0, sticky=(W, E))
dest_entry = ttk.Entry(mainframe, width=7, textvariable=dest)
dest_entry.grid(column=2, row=1, sticky=(W, E))


ttk.Label(mainframe, textvariable=meters).grid(column=2, row=2, sticky=(W, E))
ttk.Button(mainframe, text="Find Path", command=calculate).grid(column=3, row=3, sticky=W)

#ttk.Label(mainframe, text="feet").grid(column=3, row=1, sticky=W)
#ttk.Label(mainframe, text="is equivalent to").grid(column=1, row=2, sticky=E)
#ttk.Label(mainframe, text="meters").grid(column=3, row=2, sticky=W)

for child in mainframe.winfo_children(): child.grid_configure(padx=5, pady=5)

source_entry.focus()
root.bind('<Return>', calculate)

root.mainloop()
