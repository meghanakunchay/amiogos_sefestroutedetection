# using Tkinter's Optionmenu() as a combobox
#import Tkinter as tk
from Tkinter import *
import ttk
def select():
    sf = "Value is %s" % var.get()
    root.title(sf)

root = Tk()

mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)

var = StringVar(root)
# initial value
var.set('red')
choiceSource = ['red', 'green', 'blue', 'yellow','white', 'magenta']
choiceDest = ['red', 'green', 'blue', 'yellow','white', 'magenta']

source = OptionMenu(root, var, *choiceSource)
source.grid(column=2, row=0, sticky=(W, E))

dest = OptionMenu(root, var, *choiceDest)
dest.grid(column=2, row=1, sticky=(W, E))

button = Button(root, text="check value slected", command=select)
button.grid(column=2, row=2, sticky=(W, E))

root.mainloop()
