import webbrowser
import mapPath

def openThisImage():
    print 1
    webbrowser.open('result.jpg')

mapPath.drawPath()
