from Tkinter import *
import Tkinter as ttk 
from ttk import *
import safest_path
import mapPath

root = Tk()
root.title("Safest Path Finder")

mainframe = Frame(root)                                 
mainframe.grid(column=0,row=0, sticky=(N,W,E,S) )
mainframe.columnconfigure(0, weight = 1)
mainframe.rowconfigure(0, weight = 1)
mainframe.pack(pady = 10, padx = 10)

varS = StringVar(root)
varD = StringVar(root)
# Use dictionary to map locations to indices
choiceS = {
    'Najafgarh': 0,
    'Chhawala': 1,
    'Mundka': 2,
    'Kanjawla': 3,
    'South Campus': 4,
    'Dwarka': 5,
    'Bawana': 6,
    'Mianwali':7,
}
choiceD = {
    'Najafgarh': 0,
    'Chhawala': 1,
    'Mundka': 2,
    'Kanjawla': 3,
    'South Campus': 4,
    'Dwarka': 5,
    'Bawana': 6,
    'Mianwali':7,
}

option = OptionMenu(mainframe, varS, *choiceS)
varS.set('Najafgarh')
option.grid(row = 1, column =1)

option = OptionMenu(mainframe, varD, *choiceD)
varD.set('Najafgarh')
option.grid(row = 1, column =2)



indexS = StringVar()
indexD = StringVar()


# change_index is called on var change.
def change_index(*args):
    indexS_ = choiceS[varS.get()]
    indexS.set(indexS_)
    indexD_ = choiceS[varD.get()]
    indexD.set(indexD_)
    print choiceS[varS.get()],choiceD[varD.get()]
    safest_path.findPath(choiceS[varS.get()],choiceD[varD.get()])
    #meters.set(safest_path.findPath(choiceS[varS.get()],choiceD[varD.get()])
    mapPath.drawPath()
# trace the change of var
ttk.Label(mainframe, textvariable="a").grid(column=2, row=2, sticky=(W, E))
ttk.Button(mainframe, text="Find Path", command=change_index).grid(column=2, row=3, sticky=W)


root.mainloop()
