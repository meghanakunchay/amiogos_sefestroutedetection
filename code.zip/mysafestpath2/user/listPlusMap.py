from Tkinter import *
import ttk
import safest_path
#import mapPath
#import openImage
import webbrowser
import time
from PIL import Image
from PIL import ImageFont
import ImageDraw
import webbrowser
image="map.jpg"
im=Image.open(image)

import csv
with open('crime records fir.csv', 'Ur') as f:
    data = list(rec
                for rec in csv.reader(f, delimiter=','))\

r=10                #radius of dots on the map in pixels
longLeft = 76.83
longRight = 77.42
latUp = 28.9
latDown = 28.4
maxFir = 1320
def retRadius(n):
    r = float(rmin) + float(rmax-rmin)*float(n/maxFir)
    return float(r)
def retColorRatio(n):
    return int((float(n)/1500)*255)
width = im.size[0]
height = im.size[1]
px = float((longRight-longLeft)/width)  #pixel density of longitude
py = float((latUp-latDown)/height)      #pixel density of latitude
def givePoint(x1,y1):                   #return pixel from lat long
    x = float((x1-longLeft)/px)
    y = height-float((y1-latDown)/py)
    return x,y
def plotPoint(x1,y1,r,c,count):
    x,y=givePoint(x1,y1)
    print x,y
    c = retColorRatio(c)
    r=10
    draw = ImageDraw.Draw(im)
    font = ImageFont.truetype("Arial.ttf",18)
    draw.text((int(x+10), int(y+10)),str(count),(0,0,0),font=font)
    draw.ellipse((x-r, y-r, x+r, y+r), fill=(c,255-c,0))
def plotLine(x1,y1,x2,y2):
    a,b = givePoint(x1,y1)
    c,d = givePoint(x2,y2)
    draw = ImageDraw.Draw(im) 
    draw.line((a,b,c,d), fill=(0,0,255),width=6)
def drawPath():
    fopen = open("path.txt",'r')
    f = fopen.read()
    f=f.split('\n')
    print f
    for i in f[:-1]:
        j = i.split()
        temp = j[3]
        if len(j)>4:
            temp=''
            for x in j[3:]:
                temp = temp + ' ' + x
        plotPoint(float(j[0]),float(j[1]),10,int(j[2]),temp)
    for i in xrange(len(f[:-1])-1):
        j = f[i].split()
        j1= f[i+1].split()
        plotLine(float(j[0]),float(j[1]),float(j1[0]),float(j1[1]))
    im.save("result.jpg")
    fopen.close()
    webbrowser.open("result.jpg")
    return

choices = {
    'najafgarh': 0,
    'chhawala': 1,
    'mundka': 2,
    'kanjawla': 3,
    'south campus': 4,
    'dwarka': 5,
    'bawana': 6,
    'mianwali':7,
}
def calculate(*args):
    safest_path.findPath(int(choices[source.get().lower()]),int(choices[dest.get().lower()]))
    time.sleep(2)
    meters.set(safest_path.findPath(int(choices[source.get().lower()]),int(choices[dest.get().lower()])))
    drawPath()

    
    
root = Tk()
root.title("Safest Path Finder")

mainframe = ttk.Frame(root, padding="3 3 12 12")
mainframe.grid(column=0, row=0, sticky=(N, W, E, S))
mainframe.columnconfigure(0, weight=1)
mainframe.rowconfigure(0, weight=1)

feet = StringVar()
meters = StringVar()

source = StringVar()
dest = StringVar()


source_entry = ttk.Entry(mainframe, width=7, textvariable=source)
source_entry.grid(column=2, row=0, sticky=(W, E))
dest_entry = ttk.Entry(mainframe, width=7, textvariable=dest)
dest_entry.grid(column=2, row=1, sticky=(W, E))


ttk.Label(mainframe, textvariable=meters).grid(column=2, row=2, sticky=(W, E))
ttk.Button(mainframe, text="Find Path", command=calculate).grid(column=3, row=3, sticky=W)

#ttk.Label(mainframe, text="feet").grid(column=3, row=1, sticky=W)
#ttk.Label(mainframe, text="is equivalent to").grid(column=1, row=2, sticky=E)
#ttk.Label(mainframe, text="meters").grid(column=3, row=2, sticky=W)

for child in mainframe.winfo_children(): child.grid_configure(padx=5, pady=5)

source_entry.focus()
root.bind('<Return>', calculate)

root.mainloop()
