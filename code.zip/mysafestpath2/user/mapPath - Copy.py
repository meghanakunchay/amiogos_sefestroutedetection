from PIL import Image
from PIL import ImageFont
import ImageDraw
import webbrowser
import time

fp = open("map.jpg", "rb")
im = Image.open(fp) # open from file object
im.load() # make sure PIL has read the data
fp.close()

import csv
with open('crime records fir.csv', 'Ur') as f:
    data = list(rec
                for rec in csv.reader(f, delimiter=','))\

r=10                #radius of dots on the map in pixels
longLeft = 76.83
longRight = 77.42
latUp = 28.9
latDown = 28.4
maxFir = 1320
def retRadius(n):
    r = float(rmin) + float(rmax-rmin)*float(n/maxFir)
    return float(r)
def retColorRatio(n):
    return int((float(n)/1500)*255)
width = 3000
height = 3000
px = float((longRight-longLeft)/width)  #pixel density of longitude
py = float((latUp-latDown)/height)      #pixel density of latitude
def givePoint(x1,y1):                   #return pixel from lat long
    x = float((x1-longLeft)/px)
    y = height-float((y1-latDown)/py)
    return x,y
def plotPoint(x1,y1,r,c,count):
    x,y=givePoint(x1,y1)
    c = retColorRatio(c)
    r=10
    draw = ImageDraw.Draw(im)
    font = ImageFont.truetype("Arial.ttf",18)
    draw.text((int(x+10), int(y+10)),str(count),(0,0,0),font=font)
    draw.ellipse((x-r, y-r, x+r, y+r), fill=(c,255-c,0))
def plotLine(x1,y1,x2,y2):
    a,b = givePoint(x1,y1)
    c,d = givePoint(x2,y2)
    draw = ImageDraw.Draw(im) 
    draw.line((a,b,c,d), fill=(0,0,255),width=6)
#def drawPath():
fopen = open("path.txt",'r')
f = fopen.read()
f=f.split('\n')
for i in f[:-1]:
    j = i.split()
    temp = j[3]
    if len(j)>4:
        temp=''
        for x in j[3:]:
            temp = temp + ' ' + x
    plotPoint(float(j[0]),float(j[1]),10,int(j[2]),temp)
for i in xrange(len(f[:-1])-1):
    j = f[i].split()
    j1= f[i+1].split()
    plotLine(float(j[0]),float(j[1]),float(j1[0]),float(j1[1]))
im.save("result.jpg")
fopen.close()
webbrowser.open("result.jpg")
#drawPath()
