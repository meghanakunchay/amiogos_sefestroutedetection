
#!/usr/bin/python
#code needs a nX2 matrix where n is the number of police stations.the 1st column contains police station number
import operator
import csv
import math
import numpy


def mst(edgewt):  #edgeweights as adjacency matrix
    length=len(edgewt)
    '''
    dist=[]
    edgewt=[]
    for i in xrange(0,length):
        for j in xrange(0,length):
            if i==j:
                dist.append(0)
            else:
                dist.append(crime[i][1]+crime[j][1])
        edgewt.append(dist)
        dist=[]
    #print edgewt
    '''
    visited=[]
    vislist=[]
    for k in xrange(0,length):
        visited.append(0)
    #edgewt.sort(key=itemgetter(1))
    visited[0]=1
    vislist.append(0)
    mindis=999999
    mind=-1
    parent=-1
    adjl=[]
    for k in xrange(0,length):
        adjl.append([])
    while len(vislist)<length:
        for t in vislist:
            for p in xrange(0,length):
                if t!=p and edgewt[t][p]<mindis and visited[p]==0:
                    mindis=edgewt[t][p]
                    parent=t
                    mind=p
        visited[mind]=1
        vislist.append(mind)
        adjl[parent].append(mind)
        adjl[mind].append(parent)
        mindis=999999
        mind=-1
    #print adjl
    return adjl



def create_graph(dist):
    m=len(dist)
    adjl=[]
    adj=[]
    minrad=.025                      #Set minimum radius to be connected
                                  #max dist b/w 2 pts. is 0.420211564701
    minDistNode = -1
    maxLength = 0
    for x in xrange(0,m):
        minDist = 1
        for y in xrange(0,m):
            if dist[x][y]<minrad and x!=y:
                adj.append(y)
            if dist[x][y]<minDist and x!=y:
                minDist = dist[x][y]
                minDistNode = y
        if adj == []:
            adj.append(minDistNode)
        if len(adj)>maxLength:
            maxLength = len(adj)
        adjl.append(adj)
        adj=[]
    fwrite = open("adjl.txt",'w')
    for i in adjl:
        fwrite.write(str(i)+'\n')
    fwrite.close()
    return adjl

def djikastras(crime,adjl,s,d):      #s is source vertex's number and d is the destination vertex.vertex numbers are assumed to be from 0 to 164
    path=[]               #crime has vertex number and number of crimes for each police station    
    visited=[crime[s][0]] #visited contains visited vertex's number
    visin=[]
    for q in xrange(0,len(crime)):
        visin.append([0,-1,-1]) #keeps track of whether a vertex is visited or not,parent and crimes from source till there
    visin[s]=[1,-1,crime[s][1]]
    while(1):
        mind=[0,-1,999999]  #sentinel value is set [visited/not visited boolean,parent,min dist from source]
        count = 0
        for i in visited:
            for j in adjl[i]:
                #print int(crime[j][1]),int(visin[i][2]),int(mind[2])
                if int(crime[j][1])+int(visin[i][2])<int(mind[2]) and visin[j][0]==0:
                    mind=[1,i,int(crime[j][1])+int(visin[i][2])]
                    ind=j
        if mind[2]!=999999:
            visited.append(ind)
            visin[ind]=mind
        else:
            print "no path exists from source to destination"
            break
        if ind==d:
            break
    if ind==d:
        path.append(d)
        v=d
        while v!=s:
            v=visin[v][1]
            path.append(v)
        path.reverse()
    #print path
    return path
        
                
                
    

with open('../temporal_analysis/Data.csv', 'rb') as csvfile:
    
    spamreader = csv.reader(csvfile, delimiter=',', quotechar='|')
    a=[]
    for row in spamreader:
        #print ', '.join(row)
        a.append(row)
    del a[0]
    length=len(a)
    
    #CREATE DISTANCE MATRIX
    crime=[]
    for g in xrange(0,length):
        crime.append([g,a[g][1]])        
    #print length
    adj=[]
    dist=[]
    for i in xrange(0,length):
        for j in xrange(0,length):
            if i==j:
                adj.append(0)
            else:
                adj.append(math.sqrt((float(a[i][2])-float(a[j][2]))**2+(float(a[i][3])-float(a[j][3]))**2))
        dist.append(adj)
        adj=[]

    adjlMst=mst(dist)
    '''

    #WRITE ADJL_MST TO FILE
    fwrite = open("adjlMst.txt",'w')
    for i in adjlMst:
        fwrite.write(str(i)+'\n')
    fwrite.close() 
    
    adjl=create_graph(dist)
    
    adjl = []
    #READ FROM FILE TO ADJLs
    fopen = open("adjl.txt",'r')
    f = fopen.read()
    f = f.split('\n')
    for i in f[:-1]:
        i = i[1:-1]
        i= i.split(',')
        i = map(int,i)
        adjl.append(i)
    #to write path from a and adjl
    
    fwrite = open("pathSub.txt",'w')
    c=0
    for y in adjl:
        for z in y:
            fwrite.write(a[c][3]+' '+a[c][2]+' '+a[z][3]+' '+a[z][2]+'\n')
        c+=1
    fwrite.close()

    #to write path from a and adjlMst
    
    fwrite = open("pathMst.txt",'w')
    c=0
    for y in adjlMst:
        for z in y:
            fwrite.write(a[c][3]+' '+a[c][2]+' '+a[z][3]+' '+a[z][2]+'\n')
        c+=1
    fwrite.close()

    #TO SUM ADJL AND MST
    for i in xrange(0,len(adjl)):
        for j in adjlMst[i]:
            if j not in adjl[i]:
                adjl[i].append(j)
    fwrite = open("adjlSum.txt",'w')
    for i in adjl:
        fwrite.write(str(i)+'\n')
    fwrite.close()
    '''
    adjl=[]
    fopen = open("adjlSum.txt",'r')
    f = fopen.read()
    f = f.split('\n')
    for i in f[:-1]:
        i = i[1:-2]
        i= i.split(',')
        #print i
        i = map(int,i)
        adjl.append(i)
    fwrite = open("pathSum.txt",'w')
    c=0
    for y in adjl:
        for z in y:
            fwrite.write(a[c][3]+' '+a[c][2]+' '+a[z][3]+' '+a[z][2]+'\n')
        c+=1
    fwrite.close()
    

    #TAKING INPUT FROM USER
    
    def findPath(s,d):
        
        #s=raw_input('Enter source vertex\'s number:')
        #d=raw_input('Enter destination vertex\'s number:')
        path=djikastras(crime,adjl,int(s),int(d))
        #print path
        fwrite = open("path.txt",'w')
        for i in path:
            fwrite.write(a[i][3]+' '+a[i][2]+' '+a[i][1]+' '+a[i][0]+'\n')
        fwrite.close()
        st = ''
        for k in xrange(len(path)-1):
            st=st+'From ' + a[path[k]][0] + ' go to ' + a[path[k+1]][0] +'.\n'
        return st
        #for k in path[:-1]:
        #    print 'From ' + a[k][0] + ' go to ' + a[k+1][0] +'.'
    

    '''
    flag = 1
    while flag !=0:
        flag = 0
        for i in xrange(0,len(adjl)):
            for j in xrange(0,len(adjl)):
                minDist = 1
                minDistNode = -1
                if i!=j:
                    path=djikastras(crime,adjl,i,j)
                    if path == []:
                        flag = 1
                        if dist[i][j] < minDist:
                            print 1
                            minDist = dist[i][j]
                            minDistNode = j
            print adjl[i]
            print "Appending" + str(minDistNode) + "to" + str(i)
            adjl[i].append(minDistNode)
    '''
    
    
    '''
    print 
    sub_g={}
    while(len(sub_g)!=1):
        all_nodes = []
        sub_g = {}
        for i in xrange(0,length):
            all_nodes.append(i)
        visited_g=[]
        while len(all_nodes) !=0:
            visited = []
            to_visit = []
            to_visit.append(all_nodes[0])
            while len(to_visit) !=0:
                temp = to_visit[0]
                if temp not in visited_g:
                    visited.append(temp)
                    if temp not in visited_g:
                        visited_g.append(temp)
                    for i in adjl[temp]:
                        if i not in visited:
                            to_visit.append(i)
                to_visit = to_visit[1:]
            sub_g[all_nodes[0]] = visited
            all_nodes1 = []
            for i in xrange(0,len(all_nodes)):
                if all_nodes[i] not in visited_g:
                    all_nodes1.append(all_nodes[i])
            all_nodes = []
            for i in all_nodes1:
                all_nodes.append(i)
        print sub_g
    #now we have sub graphs
        for i in sub_g.keys():
            g1=-1
            g2=-1
            s1=-1
            s2=-1
            minDist=1
            for j in sub_g.keys():
                if i!=j:
                    for x in sub_g[i]:
                        for y in sub_g[j]:
                            if dist[x][y]<minDist:
                                minDist = dist[x][y]
                                g1=x
                                g2=y
                                s1=i
                                s2=j
        adjl[g1].append(g2)
        adjl[g2].append(g1)
        sub_g[s1].extend(sub_g[s2])
        del sub_g[s2]
        print sub_g
    fwrite = open("adjlNew.txt",'w')
    for i in adjl:
        fwrite.write(str(i)+'\n')
    fwrite.close()
    '''
        
    
    
        
        
