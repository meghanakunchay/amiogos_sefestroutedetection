import urllib
import simplejson
import sys

googleGeocodeUrl = 'http://maps.googleapis.com/maps/api/geocode/json?'

total = len(sys.argv)
cmdargs = str(sys.argv)
query = str(sys.argv[1])
#print query
for i in range(2,len(sys.argv)):
	query = query + " " + sys.argv[i]
from_sensor=False
query = query.encode('utf-8')
params = {
'address': query,
'sensor': "true" if from_sensor else "false"
}
url = googleGeocodeUrl + urllib.urlencode(params)
json_response = urllib.urlopen(url)
response = simplejson.loads(json_response.read())
if response['results']:
	location = response['results'][0]['geometry']['location']
	#location2 = response['results'][1]['geometry']['location']
	latitude, longitude = location['lat'], location['lng']
	#latitude2, longitude2 = location2['lat'], location2['lng']
	print query, latitude, longitude
	#print query, latitude2, longitude2
else:
	latitude, longitude = None, None
	print query, "<no results>"
