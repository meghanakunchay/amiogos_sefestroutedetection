import urllib
import simplejson
import sys
def main():
	with open('locations.txt') as f:
	    content = f.readlines()
	    for line in content:
	    #	print line
	    	query = str(line)
	    	checklatlong(query)

def checklatlong(toponym):
	googleGeocodeUrl = 'http://maps.googleapis.com/maps/api/geocode/json?'
	from_sensor=False
	toponym = toponym.encode('utf-8')
	params = {
	'address': toponym,
	'sensor': "true" if from_sensor else "false"
	}
	url = googleGeocodeUrl + urllib.urlencode(params)
	json_response = urllib.urlopen(url)
	response = simplejson.loads(json_response.read())
	if response['results']:
		location = response['results'][0]['geometry']['location']
		latitude, longitude = location['lat'], location['lng']
		print str(latitude) + "\t"+ str(longitude)
	else:
		latitude, longitude = None, None
		print toponym, "<no results>"

if __name__=='__main__':
	main()
