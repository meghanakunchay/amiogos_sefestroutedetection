import urllib
from re import *
#search = raw_input("Search parameter\n")
links = []
num = 0
base = 'http://timesofindia.indiatimes.com'
words = 'Imprisonment'.split()
for search in words:
    print search
    url = 'http://timesofindia.indiatimes.com/topic/'+search
    fi = urllib.urlopen(url)
    f = fi.read().decode("iso-8859-1")
    f = f[f.find('<div id="artext1"'):]
    f = f[f.find('</script>'):]
    f = f[f.find('</script>'):]
    f = f[:f.find('<div class="tab1">')-1]
    while f.find('<span class="imgtoi"></span>') != -1:
        f = f[f.find('<span class="imgtoi"></span>'):]
        li = str(f[f.find('<a')+9:f.find('>',f.find('<a')+1)-1])
        if li not in links:
            links.append(base+li)
        f = f[f.find('</a>',f.find('<a')+1):]

for link in links:
    print link
    fi = urllib.urlopen(link)
    f = fi.read().decode("iso-8859-1")
    f = f[f.find('<div id="mod-a-body-first-para"'):]
    f = f[:f.find('<div id="mod-a-body-after-first-para-ad-cpc" class="mod-adcpc">')]
    while f.find('<script') != -1:
        f = f[:f.find('<script')]+f[f.find('</script>',f.find('<script')+1)+9:]
    while f.find('<') != -1:
        f = f[:f.find('<')]+f[f.find('>',f.find('<')+1)+1:]
    fname = str(num)+'.txt'
    num+=1
    fwrite = open(fname,'w')
    fwrite.write(f.encode('utf-8'))
    fwrite.close()
    print "Saved"


