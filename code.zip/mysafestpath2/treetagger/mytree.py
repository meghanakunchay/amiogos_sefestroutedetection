from treetagger import TreeTagger
tt = TreeTagger(encoding='latin-1',language='english')
a = tt.tag('What is the airspeed of an unladen swallow?')
print a